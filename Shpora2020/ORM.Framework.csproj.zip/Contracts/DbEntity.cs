namespace ORM.Contracts
{
    public abstract class DbEntity
    {
        public string Id { get; set; }
    }
}