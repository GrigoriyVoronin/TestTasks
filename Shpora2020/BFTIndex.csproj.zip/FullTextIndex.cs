using System;
using System.Collections.Generic;
using BFTIndex.Models;

namespace BFTIndex
{
    public class FullTextIndex : IFullTextIndex
    {
        public void AddOrUpdate(string documentId, string text)
        {
            throw new NotImplementedException();
        }

        public void Remove(string documentId)
        {
            throw new NotImplementedException();
        }

        public MatchedDocument[] Search(string query)
        {
            throw new NotImplementedException();
        }
    }

    public class FullTextIndexFactory : IFullTextIndexFactory
    {
        public IFullTextIndex Create(string[] stopWords, Dictionary<char, char> normalizationTable)
        {
            throw new NotImplementedException();
        }
    }
}